import os
# 物理锁定 0 号显卡，关闭警告干扰
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"

# 仓库根目录与默认权重输出目录（相对路径）
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
WEIGHTS_DIR = os.path.join(BASE_DIR, "output_lora_weights_rag")
os.makedirs(WEIGHTS_DIR, exist_ok=True)

import torch
import json
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainingArguments, Trainer, DataCollatorForSeq2Seq
from peft import LoraConfig, get_peft_model

MODEL_ID = "Qwen/Qwen2.5-7B-Instruct" 
# 使用仓库 data 目录中的数据集（生成脚本会写入该文件）
DATASET_PATH = os.path.join(BASE_DIR, "data", "finetune_data_rag_500.jsonl")

print("正在加载 Tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token

print("正在加载 Qwen 7B 骨架模型...")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID, 
    torch_dtype=torch.bfloat16, 
    device_map="auto"
)

# 核心：将 RAG 参考上下文逻辑写入系统指令
TRAIN_SYSTEM_PROMPT = """你是一个高精度的静态代码分析专家。
你的任务是根据目标函数代码和给定的【参考被调用函数定义】，准确找出目标函数内部【直接调用】的所有自定义函数名。

【核心铁律】：
1. 仅将目标函数体内真正发生调用的函数放入 JSON 数组。
2. 即使【参考被调用函数定义】里提供了某个函数，如果目标函数体内没有实际调用它，也绝不准写进输出。
3. 如果目标函数没有调用任何函数，请直接输出空数组 []。
4. 输出必须是一个合法的 JSON 数组，严禁有任何解释性文字。"""

def process_function(example):
    user_content = f"""现在请严格、冷静地分析以下目标函数：

【目标函数代码】：
{example['input']}

【参考被调用函数定义】:
{example['rag_context']}

【终极校验检查】：
请检查你计划输出的每一个函数名，在【目标函数代码】中是否能够通过字面量搜索到？
- 如果代码中根本没出现这个单词，绝对禁止放入数组！
- 如果没有任何自定义函数被调用，必须输出 []！

请直接输出合法的 JSON 数组："""
    
    prompt = f"<|im_start|>system\n{TRAIN_SYSTEM_PROMPT}<|im_end|>\n<|im_start|>user\n{user_content}<|im_end|>\n<|im_start|>assistant\n"
    response = f"{example['output']}<|im_end|>"
    
    input_ids = tokenizer(prompt + response, add_special_tokens=False)["input_ids"]
    labels = tokenizer(response, add_special_tokens=False)["input_ids"]
    
    # 遮蔽 Prompt 部分的 Loss，仅对 Assistant 产生计算
    prompt_len = len(tokenizer(prompt, add_special_tokens=False)["input_ids"])
    labels = [-100] * prompt_len + labels
    
    # 适当放宽截断限制，确保能够吞下 RAG 上下文信息
    if len(input_ids) > 1280:
        input_ids = input_ids[:1280]
        labels = labels[:1280]
        
    return {"input_ids": input_ids, "labels": labels}

print("正在处理 RAG 增强数据集...")
raw_dataset = load_dataset("json", data_files=DATASET_PATH, split="train")
dataset = raw_dataset.map(process_function, remove_columns=raw_dataset.column_names)
dataset_split = dataset.train_test_split(test_size=0.1, seed=42)
train_dataset = dataset_split["train"]

peft_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj"], 
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, peft_config)

# 完美匹配 24G 显卡（开启梯度检查点，等效 Batch Size = 8）
training_args = TrainingArguments(
    output_dir=WEIGHTS_DIR, 
    per_device_train_batch_size=1,      
    gradient_accumulation_steps=8,      
    learning_rate=3e-5,                 
    logging_steps=5,                    
    num_train_epochs=3,                 
    eval_strategy="no",                
    save_strategy="no",                
    bf16=True,                         
    fp16=False,                        
    report_to="none",
    gradient_checkpointing=True,        # 物理降低显存需求
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    data_collator=DataCollatorForSeq2Seq(tokenizer=tokenizer, padding=True)
)

print("🚀 强强联手！带有 RAG 上下文理解的 LoRA 训练正式点火！")
trainer.train()

print("正在保存最终 LoRA 权重...")
model.save_pretrained(WEIGHTS_DIR)
print(f"🎉 恭喜！RAG-LoRA 专家微调圆满成功！权重已存入 {WEIGHTS_DIR}")