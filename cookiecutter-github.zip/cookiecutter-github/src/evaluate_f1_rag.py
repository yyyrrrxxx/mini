import os
# 物理锁定 0 号显卡，关闭多线程冲突与警告
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import torch
import json
import re
import ast as ast_literal
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel  # 用于动态加载和融合 LoRA 权重
from datasets import load_dataset

# 脚本根目录（仓库根）
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# --- 1. 基础配置与权重路径 ---
BASE_MODEL = "Qwen/Qwen2.5-7B-Instruct"
# 使用相对路径：仓库根的 output_lora_weights_rag 目录
LORA_WEIGHTS_PATH = os.path.join(BASE_DIR, "output_lora_weights_rag")
# 指向仓库 data 目录中现有的数据（兼容已有的 finetune_data_500_real.jsonl）
TEST_DATASET_PATH = os.path.join(BASE_DIR, "data", "finetune_data_500_real.jsonl")

# --- 2. 加载 Tokenizer 并合并双层网络 ---
print("1/3 正在加载基础 Tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, trust_remote_code=True)

print("2/3 正在装载 Qwen2.5 基座骨架模型...")
base_model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL, 
    torch_dtype=torch.bfloat16, 
    device_map="auto"
)

print("3/3 💥 正在合并 RAG 专属的 LoRA 权重...")
# 挂载我们在训练阶段保存的 LoRA 神经元权重
model = PeftModel.from_pretrained(base_model, LORA_WEIGHTS_PATH)
model = model.eval()  # 锁定评测推理模式
print("🎉 RAG-LoRA 静态分析专家模型挂载合并成功！")

# --- 3. 严格对齐训练阶段的 System Prompt 核心铁律 ---
SYSTEM_PROMPT = """你是一个高精度的静态代码 analysis 专家。
你的任务是根据目标函数代码和给定的【参考被调用函数定义】，准确找出目标函数内部【直接调用】的所有自定义函数名。

【核心铁律】：
1. 仅将目标函数体内真正发生调用的函数放入 JSON 数组。
2. 即使【参考被调用函数定义】里提供了某个函数，如果目标函数体内没有实际调用它，也绝不准写进输出。
3. 如果目标函数没有调用任何函数，请直接输出空数组 []。
4. 输出必须是一个合法的 JSON 数组，严禁有任何解释性文字。"""

# --- 4. 严谨的 F1 矩阵计算公式 ---
def compute_f1(pred, gt):
    p_set, g_set = set(pred), set(gt)
    # 双方均为空代表预测全对（无调用情况下的完美预测）
    if not g_set and not p_set: return 1.0
    # 单方为空代表完全不匹配
    if not g_set or not p_set: return 0.0
    
    inter = len(p_set & g_set)
    if inter == 0: return 0.0
    
    p = inter / len(p_set)
    r = inter / len(g_set)
    return 2 * p * r / (p + r)

# --- 5. 批量推理测试集（实时流式曝分） ---
test_raw = load_dataset("json", data_files=TEST_DATASET_PATH, split="train")

# 选取数据集后部未直接参与权重首轮更新的多样化留出集作为独立测试集
test_cases = test_raw.select(range(len(test_raw) - 81, len(test_raw)))

total_f1 = 0.0
count = 0

print(f"\n🚀 开启【FT + RAG 终极形态】独立测试集推理评测（实时爆分流）...")
for idx, item in enumerate(test_cases):
    func_name = item.get("function_name", "unknown")
    code = item.get("code", item.get("input", ""))
    gt = item.get("ground_truth", item.get("output", []))
    rag_context = item.get("rag_context", "无额外参考")
    
    # 解析标准答案
    if isinstance(gt, str):
        try:
            gt = json.loads(gt)
        except:
            pass

    # 严格对齐 lora_train_rag.py 的输入 Prompt 模版
    user_content = f"""现在请严格、冷静地分析以下目标函数：

【目标函数代码】：
{code}

【参考被调用函数定义】:
{rag_context}

【终极校验检查】：
请检查你计划输出的每一个函数名，在【目标函数代码】中是否能够通过字面量搜索到？
- 如果代码中根本没出现这个单词，绝对禁止放入数组！
- 如果没有任何自定义函数被调用，必须输出 []！

请直接输出合法的 JSON 数组："""

    full_prompt = f"<|im_start|>system\n{SYSTEM_PROMPT}<|im_end|>\n<|im_start|>user\n{user_content}<|im_end|>\n<|im_start|>assistant\n"

    # 执行硬件推理
    inputs = tokenizer([full_prompt], return_tensors="pt").to("cuda")
    with torch.no_grad():
        outputs = model.generate(
            **inputs, 
            max_new_tokens=128, 
            do_sample=False  # 闭环测试锁死绝对理性答案
        )
        
    # 抽取 Assistant 回答片段
    raw_output = tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]
    clean_output = raw_output.split("assistant")[-1].strip()
    
    # 稳健提取首个合规的 JSON 数组结构
    try:
        match = re.search(r'\[.*\]', clean_output, re.S)
        pred = ast_literal.literal_eval(match.group()) if match else []
    except:
        pred = []
        
    current_f1 = compute_f1(pred, gt)
    total_f1 += current_f1
    count += 1
    
    # 实时流式输出分数，不让终端沉默
    print(f"🌟 [Case {count}/{len(test_cases)}] 函数: {func_name} | 单步 F1: {current_f1:.4f} | 累计实时平均 F1: {total_f1 / count:.4f}")

print("\n" + "="*60)
print(f"🏆🏆🏆 【FT + RAG 终极融合方案】最终独立测试平均 F1 分数: {total_f1 / count:.4f} 🏆🏆🏆")
print("="*60)